update openmrs.obs o set  o.value_datetime = DATE_FORMAT(o.value_datetime, '2010-%m-%d 00:00:00') where obs_id = 1573707 ;
update openmrs.obs o set  o.value_datetime = DATE_FORMAT(o.value_datetime, '2013-%m-%d 00:00:00') where obs_id = 1636169 ;
update openmrs.obs o set  o.value_datetime = DATE_FORMAT(o.value_datetime, '2012-%m-%d 00:00:00') where obs_id = 1654740 ;
update openmrs.obs o set  o.value_datetime = DATE_FORMAT(o.value_datetime, '2014-%m-%d 00:00:00') where obs_id = 1662958 ;
update openmrs.obs o set  o.value_datetime = DATE_FORMAT(o.value_datetime, '2013-%m-%d 00:00:00') where obs_id = 1814497 ;
update openmrs.obs o set  o.value_datetime = DATE_FORMAT(o.value_datetime, '2012-%m-%d 00:00:00') where obs_id = 1919713 ;
update openmrs.obs o set  o.value_datetime = DATE_FORMAT(o.value_datetime, '2017-%m-%d 00:00:00') where obs_id = 2740003 ;
update openmrs.obs o set  o.value_datetime = DATE_FORMAT(o.value_datetime, '2022-%m-%d 00:00:00') where obs_id = 6503534 ;

SET FOREIGN_KEY_CHECKS=0;
drop table if exists sync_server_record;
drop table if exists sync_server_class;
drop table if exists sync_server;
drop table if exists sync_class;
drop table if exists sync_record;
drop table if exists sync_import;
SET FOREIGN_KEY_CHECKS=1;
delete from global_property where property like 'sync.%';
SET SQL_SAFE_UPDATES=0;
DELETE FROM scheduler_task_config_property WHERE name IN ('delete_entries_files_older_than_x_days','sync_record_states_to_delete');
DELETE FROM scheduler_task_config WHERE name IN('Cleanup Old Sync Records','SmsReminderTask');
SET SQL_SAFE_UPDATES=1;

