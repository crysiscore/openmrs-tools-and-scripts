update openmrs.obs o set  o.value_datetime = DATE_FORMAT(o.value_datetime, '2020-%m-%d 00:00:00') where obs_id = 8613266 ;
update openmrs.obs o set  o.value_datetime = DATE_FORMAT(o.value_datetime, '2018-%m-%d 00:00:00') where obs_id = 4942305 ;
update openmrs.obs o set  o.value_datetime = DATE_FORMAT(o.value_datetime, '2017-%m-%d 00:00:00') where obs_id = 3805199 ;
update openmrs.obs o set  o.value_datetime = DATE_FORMAT(o.value_datetime, '2018-%m-%d 00:00:00') where obs_id = 5108745 ;
update openmrs.obs o set  o.value_datetime = DATE_FORMAT(o.value_datetime, '2019-%m-%d 00:00:00') where obs_id = 5494342 ;
update openmrs.obs o set  o.value_datetime = DATE_FORMAT(o.value_datetime, '2019-%m-%d 00:00:00') where obs_id = 5599524 ;

SET FOREIGN_KEY_CHECKS=0;
drop table if exists sync_server_record;
drop table if exists sync_server_class;
drop table if exists sync_server;
drop table if exists sync_class;
drop table if exists sync_record;
drop table if exists sync_import;
SET FOREIGN_KEY_CHECKS=1;
delete from global_property where property like 'sync.%';
SET SQL_SAFE_UPDATES=0;
DELETE FROM scheduler_task_config_property WHERE name IN ('delete_entries_files_older_than_x_days','sync_record_states_to_delete');
DELETE FROM scheduler_task_config WHERE name IN('Cleanup Old Sync Records','SmsReminderTask');
SET SQL_SAFE_UPDATES=1;

